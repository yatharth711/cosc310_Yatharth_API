package jUnitTester;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class dbLogin_Test {

	@Test
	void test() {
		
	}

}
